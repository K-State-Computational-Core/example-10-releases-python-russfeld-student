"""Test Package for guessing game.

Author: Russell Feldhausen russfeld@ksu.edu
Version: 0.1
"""
